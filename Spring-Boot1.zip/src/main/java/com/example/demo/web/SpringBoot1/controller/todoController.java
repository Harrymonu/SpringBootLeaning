package com.example.demo.web.SpringBoot1.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.example.demo.web.SpringBoot1.model.Todo;
import com.example.demo.web.SpringBoot1.service.LoginService;
import com.example.demo.web.SpringBoot1.service.TodoService;

@SessionAttributes("name")
@Controller
public class todoController {

	@Autowired
	TodoService todoservice;

	@InitBinder
	public void InitBinder(WebDataBinder binder) {
     SimpleDateFormat simpledate=new SimpleDateFormat("dd/mm/yyyy");
     binder.registerCustomEditor(Date.class,new CustomDateEditor(simpledate,false));
	}

	@RequestMapping(value = "/todolist", method = RequestMethod.GET)
	public String gototodolist(ModelMap map) {
		String name = GetLoggendInUserName(map);
		map.put("tododata", todoservice.retrieveTodos(name));
		return "todolist";
	}

	private String GetLoggendInUserName(ModelMap map) {
		 Object principal=  SecurityContextHolder.getContext().getAuthentication().getPrincipal();
	     if(principal instanceof UserDetails) {
	   return 	((UserDetails)principal).getUsername();
	     }
			return principal.toString();
	}

	@RequestMapping(value = "/add-todolist", method = RequestMethod.GET)
	public String showtodolist(ModelMap map) {
//		map.addAttribute("todo",new Todo(0,(String)map.get("name")," " ,new Date(),false);
		map.addAttribute("todo", new Todo(0, GetLoggendInUserName(map), "default", new Date(), false));
		return "addtodolist";
	}

	@RequestMapping(value = "/add-todolist", method = RequestMethod.POST)
	public String addtodolist(ModelMap map, @Valid Todo todo, BindingResult result) {

		if (result.hasErrors()) {
			return "addtodolist";
		}
		todoservice.addTodo(GetLoggendInUserName(map), todo.getDesc(),todo.getTargetDate(), false);
		return "redirect:/todolist";
	}

	@RequestMapping(value = "/delete-todo", method = RequestMethod.GET)
	public String deletetodo(ModelMap map, @RequestParam int id) {
		if(id==1)
			throw new RuntimeException("Something went wrong");
		
		todoservice.deleteTodo(id);
		return "redirect:/todolist";
	}

	@RequestMapping(value = "/update-todo", method = RequestMethod.GET)
	public String showupdatetodo(ModelMap map, @RequestParam int id) {
		System.out.println("DFDFDFDFDFDFFDFD" + todoservice.retrieveTodo(id));
		map.put("todo", todoservice.retrieveTodo(id));
		return "addtodolist";
	}

	@RequestMapping(value = "/update-todo", method = RequestMethod.POST)
	public String updatetodo(ModelMap map, @Valid Todo todo, BindingResult result) {

		todo.setUser(GetLoggendInUserName(map));
		if (result.hasErrors()) {
			return "addtodolist";
		}

		todoservice.updattodo(todo);
		return "redirect:/todolist";
	}

}
