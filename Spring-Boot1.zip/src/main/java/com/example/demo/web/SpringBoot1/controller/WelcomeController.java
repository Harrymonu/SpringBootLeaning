package com.example.demo.web.SpringBoot1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.example.demo.web.SpringBoot1.service.LoginService;

@Controller
@SessionAttributes("name")
public class WelcomeController {
	@Autowired
	LoginService loginservice;

	@RequestMapping(value="/",method=RequestMethod.GET)
    public String welcomepage(ModelMap map) {
        map.put("name",getLoggedInUserName());
//		map.put("password","12345");
		
		return "welcome";
		//return "login";
	}
	
	private String getLoggedInUserName( ) {
     Object principal=  SecurityContextHolder.getContext().getAuthentication().getPrincipal();
     if(principal instanceof UserDetails) {
   return 	((UserDetails)principal).getUsername();
     }
		return principal.toString();
		
		
	}

//	@RequestMapping(value = "/", method = RequestMethod.POST)
//	public String loginshowMessage(ModelMap map, @RequestParam String name, String password) {
////		System.out.println("name is="+name);
//
//		if (!loginservice.getstatus(name, password)) {
//			map.put("error", "wrong password");
//			return "login";
//		}
//		map.put("name", name);
//		map.put("password", password);
//
//		return "welcome";
//	}

}
