package com.example.demo.web.SpringBoot1.service;

import java.sql.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.web.SpringBoot1.model.Todo;

@Component
public class LoginService {
   

	public boolean getstatus(String name ,String password) {
//		Todo todo=new Todo(0,name,password, new Date,false);
		
		return name.equals("Harry") && password.equals("12345"); 
	}
}
