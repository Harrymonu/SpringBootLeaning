package com.example.demo.web.SpringBoot1.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.net.openssl.ciphers.Authentication;
import org.eclipse.jdt.internal.compiler.lookup.AnnotationHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.resource.HttpResource;

import com.example.demo.web.SpringBoot1.service.LoginService;

@Controller
@SessionAttributes("name")
public class loggoutController {
	@Autowired
	LoginService loginservice;

	@RequestMapping(value="/logout",method=RequestMethod.GET)
    public String logout(HttpServletRequest request,HttpResource response) {
		org.springframework.security.core.Authentication auth = SecurityContextHolder.getContext()
				.getAuthentication();
		if (auth != null) {
			new SecurityContextLogoutHandler().logout(request, (HttpServletResponse) response, auth);
		}
		return "redirect:/";
	}
	
	private String getLoggedInUserName( ) {
     Object principal=  SecurityContextHolder.getContext().getAuthentication().getPrincipal();
     if(principal instanceof UserDetails) {
   return 	((UserDetails)principal).getUsername();
     }
		return principal.toString();
		
		
	}

//	@RequestMapping(value = "/", method = RequestMethod.POST)
//	public String loginshowMessage(ModelMap map, @RequestParam String name, String password) {
////		System.out.println("name is="+name);
//
//		if (!loginservice.getstatus(name, password)) {
//			map.put("error", "wrong password");
//			return "login";
//		}
//		map.put("name", name);
//		map.put("password", password);
//
//		return "welcome";
//	}

}
